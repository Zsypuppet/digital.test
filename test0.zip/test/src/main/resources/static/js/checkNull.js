﻿function checkNull(){
	var bookName=$("#book_name").val();
	var bookAuthor=$("#book_author").val();
	var bookPrice=$("#book_price").val();
	
	if(bookName==""){
		$("#nameSpan").css("color","red");
		$("#nameSpan").html("书名不能为空");
		return false;
	}else if(bookName!=""){
		$("#nameSpan").css("color","green");
		$("#nameSpan").html("(●'◡'●)");
		}
	
	if(bookAuthor==""){
		$("#authorSpan").css("color","red");
		$("#authorSpan").html("作者不能为空");
		return false;
	}else if(bookAuthor!=""){
		$("#authorSpan").css("color","green");
		$("#authorSpan").html("(●'◡'●)");
		}
	
	if(bookPrice==""){
		$("#priceSpan").css("color","red");
		$("#priceSpan").html("价格不能为空");
		return false;
	}else if(bookPrice!=""){
		$("#priceSpan").css("color","green");
		$("#priceSpan").html("(●'◡'●)");
	}
}