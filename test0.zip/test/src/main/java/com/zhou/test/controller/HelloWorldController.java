/**
 * Project Name:test
 * File Name:HelloWorldController.java
 * Package Name:com.zhou.test.controller
 * Date:2018年9月1日下午1:29:33
 * Copyright (c) 2018, Rochester.zhou@clpsglobal.com All Rights Reserved.
 *
 */
package com.zhou.test.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * ClassName: HelloWorldController
 * Description: 
 * date: 2018年9月1日 下午1:29:33
 *
 * @author Rochester.Zhou
 * @version V1.0
 */
@RestController
public class HelloWorldController {
	
  @RequestMapping("/hello")
    public String index() {
        return "Hello World";
    }
}
