/**
 * Project Name:test
 * File Name:Book.java
 * Package Name:com.zhou.test.bean
 * Date:2018年9月1日下午2:23:46
 * Copyright (c) 2018, Rochester.zhou@clpsglobal.com All Rights Reserved.
 *
 */
package com.zhou.test.bean;

import java.io.Serializable;


/**
 * ClassName: Book
 * Description: 书籍实体类
 * date: 2018年9月1日 下午2:23:46
 *
 * @author Rochester.Zhou
 * @version V1.0
 */
public class Book implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Integer book_id;			//书籍id
	private String book_name;			//书籍名称
	private String book_desc;			//书籍描述	
	private String book_author;			//书籍作者
	private Double book_price;			//书籍价格
	
	/**
	 * Creates a new instance of Book.
	 *
	 */
	public Book() {
	}

	/**
	 * book_id.
	 *
	 * @return  the book_id
	 */
	public final Integer getBook_id() {
		return book_id;
	}

	/**
	 * book_id.
	 *
	 * @param   book_id    the book_id to set
	 */
	public final void setBook_id(Integer book_id) {
		this.book_id = book_id;
	}

	/**
	 * book_name.
	 *
	 * @return  the book_name
	 */
	public final String getBook_name() {
		return book_name;
	}

	/**
	 * book_name.
	 *
	 * @param   book_name    the book_name to set
	 */
	public final void setBook_name(String book_name) {
		this.book_name = book_name;
	}

	/**
	 * book_desc.
	 *
	 * @return  the book_desc
	 */
	public final String getBook_desc() {
		return book_desc;
	}

	/**
	 * book_desc.
	 *
	 * @param   book_desc    the book_desc to set
	 */
	public final void setBook_desc(String book_desc) {
		this.book_desc = book_desc;
	}

	/**
	 * book_author.
	 *
	 * @return  the book_author
	 */
	public final String getBook_author() {
		return book_author;
	}

	/**
	 * book_author.
	 *
	 * @param   book_author    the book_author to set
	 */
	public final void setBook_author(String book_author) {
		this.book_author = book_author;
	}

	/**
	 * book_price.
	 *
	 * @return  the book_price
	 */
	public final Double getBook_price() {
		return book_price;
	}

	/**
	 * book_price.
	 *
	 * @param   book_price    the book_price to set
	 */
	public final void setBook_price(Double book_price) {
		this.book_price = book_price;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Book [book_id=" + book_id + ", book_name=" + book_name + ", book_desc=" + book_desc + ", book_author="
				+ book_author + ", book_price=" + book_price + "]";
	}
	
}
