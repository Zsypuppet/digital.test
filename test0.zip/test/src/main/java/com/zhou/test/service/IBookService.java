/**
 * Project Name:test
 * File Name:IBookService.java
 * Package Name:com.zhou.test.service
 * Date:2018年9月3日上午9:02:49
 * Copyright (c) 2018, Rochester.zhou@clpsglobal.com All Rights Reserved.
 *
 */
package com.zhou.test.service;

import java.util.List;

import com.zhou.test.bean.Book;

/**
 * ClassName: IBookService
 * Description: 
 * date: 2018年9月3日 上午9:02:49
 *
 * @author Rochester.Zhou
 * @version V1.0
 */
public interface IBookService {
	
	/**
	 * 
	 * showAllBook:显示所有书籍.
	 *
	 * @author Rochester.Zhou
	 * @return
	 */
	List<Book> showAllBook();
	
	/**
	 * 
	 * findOneBook:通过id查找单个书籍.
	 *
	 * @author Rochester.Zhou
	 * @param book_id
	 * @return
	 */
	Book findOneBook(Integer book_id);
	
	/**
	 * 
	 * saveBook:新增一本书籍.
	 *
	 * @author Rochester.Zhou
	 * @param book
	 */
	void saveBook(Book book);
	
	/**
	 * 
	 * deleteBook:删除一本书籍.
	 *
	 * @author Rochester.Zhou
	 * @param book_id
	 */
	void deleteBook(Integer book_id);
	
	/**
	 * 
	 * updateBook:更新书籍.
	 *
	 * @author Rochester.Zhou
	 * @param book
	 */
	void updateBook(Book book);
	
}
