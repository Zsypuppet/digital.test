/**
 * Project Name:test
 * File Name:BookServiceImpl.java
 * Package Name:com.zhou.test.service.impl
 * Date:2018年9月3日上午9:12:32
 * Copyright (c) 2018, Rochester.zhou@clpsglobal.com All Rights Reserved.
 *
 */
package com.zhou.test.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zhou.test.bean.Book;
import com.zhou.test.dao.BookMapper;
import com.zhou.test.service.IBookService;

/**
 * ClassName: BookServiceImpl
 * Description: BookService层实现
 * date: 2018年9月3日 上午9:12:32
 *
 * @author Rochester.Zhou
 * @version V1.0
 */
@Service
public class BookServiceImpl implements IBookService{
	
	@Autowired
	BookMapper bookMapper;

	/**
	 * @see com.zhou.test.service.IBookService#showAllBook()
	 */
	@Override
	public List<Book> showAllBook() {
		return bookMapper.findAllBook();
	}

	/**
	 * @see com.zhou.test.service.IBookService#findOneBook(java.lang.Integer)
	 */
	@Override
	public Book findOneBook(Integer book_id) {
		return bookMapper.findBookById(book_id);
	}

	/**
	 * @see com.zhou.test.service.IBookService#saveBook(com.zhou.test.bean.Book)
	 */
	@Override
	public void saveBook(Book book) {
		bookMapper.saveBook(book);
	}

	/**
	 * @see com.zhou.test.service.IBookService#deleteBook(java.lang.Integer)
	 */
	@Override
	public void deleteBook(Integer book_id) {
		bookMapper.deleteBookById(book_id);
	}

	/**
	 * @see com.zhou.test.service.IBookService#updateBook(com.zhou.test.bean.Book)
	 */
	@Override
	public void updateBook(Book book) {
		bookMapper.updateBook(book);
	}

}
