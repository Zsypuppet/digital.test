/**
 * Project Name:book_sys
 * File Name:BookService.java
 * Package Name:com.sys.demo.service
 * Date:2018年9月3日下午5:49:04
 * Copyright (c) 2018, 1095151450@qq.com All Rights Reserved.
 *
 */
package com.sys.demo.service;
import java.util.List;


import com.sys.demo.model.Book;
/**
 * ClassName: BookService <br/>
 * Description: TODO ADD REASON(可选). <br/><br/>
 * date: 2018年9月3日 下午5:49:04 <br/>
 *
 * @author david.dou
 * @version V1.0
 * @since JDK 1.8
 */

public interface BookService {
	public Book findByBook_id(int book_id) throws Exception;
	public List<Book> findAll() throws Exception;
	public void save(Book book) throws Exception;
	public void delete(int book_id) throws Exception;
	public void update(Book book) throws Exception;
}
