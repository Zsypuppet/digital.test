/**
 * Project Name:book_sys
 * File Name:BaseDao.java
 * Package Name:com.sys.demo.dao
 * Date:2018年9月3日下午5:32:54
 * Copyright (c) 2018, 1095151450@qq.com All Rights Reserved.
 *
 */
package com.sys.demo.dao;

/**
 * ClassName: BaseDao <br/>
 * Description: TODO ADD REASON(可选). <br/><br/>
 * date: 2018年9月3日 下午5:32:54 <br/>
 *
 * @author david.dou
 * @version V1.0
 * @since JDK 1.8
 */
import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.NoRepositoryBean;
/**
 * 继承DAO
 * 自定义的 XxxxRepository 需要继承 JpaRepository，这样的 XxxxRepository 接口就具备了通用的数据访问控制层的能力。
 * JpaSpecificationExecutor： 不属于Repository体系，实现一组 JPA Criteria 查询相关的方法 。
 * 
 **/
@NoRepositoryBean
public interface BaseDao<T> extends JpaRepository<T, Serializable>,JpaSpecificationExecutor<T> {

}