/**
 * Project Name:book_sys
 * File Name:Book.java
 * Package Name:com.sys.demo.model
 * Date:2018年9月3日下午5:30:53
 * Copyright (c) 2018, 1095151450@qq.com All Rights Reserved.
 *
 */
package com.sys.demo.model;

/**
 * ClassName: Book <br/>
 * Description: 书籍实体. <br/><br/>
 * date: 2018年9月3日 下午5:30:53 <br/>
 *
 * @author david.dou
 * @version V1.0
 * @since JDK 1.8
 */
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
@Entity
@Table(name="book")
public class Book {    
    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int book_id;//书籍编号

    @NotNull
    @Column(name="book_name")
    private  String book_name;//书籍名字

    @NotNull
    @Column(name="book_author")
    private  String book_author;//书籍作者
    
    @NotNull
    @Column(name="book_type")
    private  String book_type;//书籍类型

    @NotNull
    @Column(name="book_press")
    private  String book_press;//书籍出版社

	/**
	 * Creates a new instance of Book.
	 *
	 */
	
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * book_id.
	 *
	 * @return  the book_id
	 * @since   JDK 1.8
	 */
	public int getBook_id() {
		return book_id;
	}

	/**
	 * book_id.
	 *
	 * @param   book_id    the book_id to set
	 * @since   JDK 1.8
	 */
	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}

	/**
	 * book_name.
	 *
	 * @return  the book_name
	 * @since   JDK 1.8
	 */
	public String getBook_name() {
		return book_name;
	}

	/**
	 * book_name.
	 *
	 * @param   book_name    the book_name to set
	 * @since   JDK 1.8
	 */
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}

	/**
	 * book_author.
	 *
	 * @return  the book_author
	 * @since   JDK 1.8
	 */
	public String getBook_author() {
		return book_author;
	}

	/**
	 * book_author.
	 *
	 * @param   book_author    the book_author to set
	 * @since   JDK 1.8
	 */
	public void setBook_author(String book_author) {
		this.book_author = book_author;
	}

	/**
	 * book_type.
	 *
	 * @return  the book_type
	 * @since   JDK 1.8
	 */
	public String getBook_type() {
		return book_type;
	}

	/**
	 * book_type.
	 *
	 * @param   book_type    the book_type to set
	 * @since   JDK 1.8
	 */
	public void setBook_type(String book_type) {
		this.book_type = book_type;
	}

	/**
	 * book_press.
	 *
	 * @return  the book_press
	 * @since   JDK 1.8
	 */
	public String getBook_press() {
		return book_press;
	}

	/**
	 * book_press.
	 *
	 * @param   book_press    the book_press to set
	 * @since   JDK 1.8
	 */
	public void setBook_press(String book_press) {
		this.book_press = book_press;
	}
    
    
}