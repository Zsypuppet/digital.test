/**
 * Project Name:book_sys
 * File Name:WebController.java
 * Package Name:com.sys.demo.controller
 * Date:2018年9月3日下午11:37:51
 * Copyright (c) 2018, 1095151450@qq.com All Rights Reserved.
 *
 */
package com.sys.demo.controller;


import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.sys.demo.model.Book;
import com.sys.demo.service.BookService;

/**
 * ClassName: WebController <br/>
 * Description: TODO ADD REASON(可选). <br/>
 * <br/>
 * date: 2018年9月3日 下午11:37:51 <br/>
 *
 * @author david.dou
 * @version V1.0
 * @since JDK 1.8
 */
@Controller
@RequestMapping("/book")
public class WebController {

	@Resource
	private BookService bookService;

	@RequestMapping
	public String book(HttpServletRequest request) throws Exception {
		List<Book> clist = bookService.findAll();
		request.getSession().setAttribute("clist", clist);
		return "book";
	}

	@RequestMapping(value = "/update")
	public String updateBook(HttpServletRequest request, String id) throws Exception, Exception {
		Book book = this.bookService.findByBook_id(Integer.valueOf(id));
		request.getSession().setAttribute("book", book);
		return "do_book_update";
	}

	@RequestMapping(value = "/delete")
	public String deleteBook(HttpServletRequest request, String id) throws Exception, Exception {
		this.bookService.delete(Integer.valueOf(id));
		return "redirect:/book";
	}
	
	@RequestMapping(value = "/save")
	public String saveBook(HttpServletRequest request) throws Exception, Exception {
		return "do_book_insert";
	}

	@RequestMapping(value = "/insert" , method= RequestMethod.POST)
	public String insertBook(HttpServletRequest request,String book_name,String book_author,String book_press,String book_type) throws Exception, Exception {
		Book book =new Book();
		book.setBook_name(book_name);
		book.setBook_author(book_author);
		book.setBook_press(book_press);
		book.setBook_type(book_type);
		bookService.save(book);
		return "redirect:/book";
	}
	
	@RequestMapping(value = "/updateBook" , method= RequestMethod.PUT)
	public String updatetBook(HttpServletRequest request,String book_id,String book_name,String book_author,String book_press,String book_type) throws Exception, Exception {
		Book book =new Book();
		book.setBook_id(Integer.valueOf(book_id));
		book.setBook_name(book_name);
		book.setBook_author(book_author);
		book.setBook_press(book_press);
		book.setBook_type(book_type);
		bookService.update(book);
		return "redirect:/book";
	}
}
