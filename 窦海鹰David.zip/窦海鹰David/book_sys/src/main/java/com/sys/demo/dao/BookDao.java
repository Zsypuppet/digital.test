/**
 * Project Name:book_sys
 * File Name:BookDao.java
 * Package Name:com.sys.demo.dao
 * Date:2018年9月3日下午5:33:29
 * Copyright (c) 2018, 1095151450@qq.com All Rights Reserved.
 *
 */
package com.sys.demo.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;

/**
 * ClassName: BookDao <br/>
 * Description: TODO ADD REASON(可选). <br/><br/>
 * date: 2018年9月3日 下午5:33:29 <br/>
 *
 * @author david.dou
 * @version V1.0
 * @since JDK 1.8
 */

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sys.demo.model.Book;


@Repository
public interface BookDao extends BaseDao<Book> {

    @Query("select t from Book t where  t.book_id = ?1")
    public Book findByBook_id(int book_id);
    
    public List<Book> findAll();
    
    @Modifying
    @Transactional
    @Query("delete from Book es where es.book_id = ?1")
    int deleteByBook_id(int book_id);
    
    
    @Modifying
    @Transactional
    @Query(value = "insert into book(book_author,book_name,book_press,book_type) values(?1,?2,?3,?4)",nativeQuery = true)
    int addBook(String book_author,String book_name,String book_press,String book_type);
    
    @Modifying
    @Transactional
    @Query(value = "update book set book_author=?2,book_name=?3,book_press=?4,book_type=?5 where book_id=?1",nativeQuery = true)
    int updateBook(int book_id,String book_author,String book_name,String book_press,String book_type);
    
}