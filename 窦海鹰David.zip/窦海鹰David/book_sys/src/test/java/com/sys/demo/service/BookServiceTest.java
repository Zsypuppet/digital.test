/**
 * Project Name:book_sys
 * File Name:BookServiceTest.java
 * Package Name:com.sys.demo.service
 * Date:2018年9月3日下午10:48:16
 * Copyright (c) 2018, 1095151450@qq.com All Rights Reserved.
 *
 */
package com.sys.demo.service;


import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.test.context.junit4.SpringRunner;

import com.sys.demo.BookSysApplication;
import com.sys.demo.model.Book;

/**
 * ClassName: BookServiceTest <br/>
 * Description: TODO ADD REASON(可选). <br/><br/>
 * date: 2018年9月3日 下午10:48:16 <br/>
 *
 * @author david.dou
 * @version V1.0
 * @since JDK 1.8
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = BookSysApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@EnableAutoConfiguration
public class BookServiceTest {
	@Autowired
	BookService bs;
	/**
	 * Test method for {@link com.sys.demo.service.BookService#findAllBooks()}.
	 * @throws Exception 
	 */
	@Test
	public final void testFindAllBooks() throws Exception {
		List<Book> list=bs.findAll();
		for(Book attribute : list) {
			  System.out.println(attribute.getBook_name());
			}
	}

	/**
	 * Test method for {@link com.sys.demo.service.BookService#findByBook_id(java.lang.String)}.
	 * @throws Exception 
	 */
	@Test
	public final void testFindByBook_id() throws Exception {
		Book bo=new Book();
		bo=bs.findByBook_id(1);
		System.out.println(bo.getBook_name());
	}

	@Test
	public final void testSave() throws Exception {
		Book bo=new Book();
		bo.setBook_author("张三");
		bo.setBook_name("数学");
		bo.setBook_press("上海出版社");
		bo.setBook_type("理科");
		bs.save(bo);
		System.out.println(1);
	}
	
	@Test
	public final void testUpdate() throws Exception {
		Book bo=new Book();
		bo.setBook_id(1);
		bo.setBook_author("张三");
		bo.setBook_name("数学");
		bo.setBook_press("上海出版社");
		bo.setBook_type("理科");
		bs.update(bo);
		System.out.println(1);
	}
}
