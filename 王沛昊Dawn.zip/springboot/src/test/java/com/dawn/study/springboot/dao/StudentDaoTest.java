/**
 * Project Name:springboot
 * File Name:StudentDaoTest.java
 * Package Name:com.dawn.study.springboot
 * Date:2018年9月3日下午2:17:55
 * Copyright (c) 2018, 806768654@qq.com All Rights Reserved.
 *
 */
package com.dawn.study.springboot.dao;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.junit4.SpringRunner;

import com.dawn.study.springboot.dao.IStudentDao;
import com.dawn.study.springboot.model.Student;

/**
 * ClassName: StudentDaoTest <br/>
 * Description: StudentDao的测试类 <br/>
 * <br/>
 * date: 2018年9月3日 下午2:17:55 <br/>
 *
 * @author dawn.constantine
 * @version V1.0
 * @since JDK 1.8
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class StudentDaoTest {
	@Resource(name = "iStudentDao")
	private IStudentDao iStudentDao;

	@Test
	public void testAddStudent() {
		Student stu = new Student();
		stu.setStuId(151003530203l);
		stu.setStuName("王沛昊");
		stu.setStuGender("男");
		stu.setStuClass("软件1512");
		stu.setStuMajor("软件工程");
		iStudentDao.save(stu);
		System.out.println(iStudentDao.findAll().get(0).getStuName());
	}

	@Test
	public void testFindAllStudentPageable() {
		iStudentDao.findAll(PageRequest.of(0, 10));
	}
}
