/**
 * Project Name:springboot
 * File Name:StudentServiceImpl.java
 * Package Name:com.dawn.study.springboot.service.impl
 * Date:2018年9月3日下午5:03:33
 * Copyright (c) 2018, 806768654@qq.com All Rights Reserved.
 *
 */
package com.dawn.study.springboot.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.dawn.study.springboot.dao.IStudentDao;
import com.dawn.study.springboot.model.Student;
import com.dawn.study.springboot.service.IStudentService;

/**
 * ClassName: StudentServiceImpl <br/>
 * Description: 学生service实现类 <br/>
 * <br/>
 * date: 2018年9月3日 下午5:03:33 <br/>
 *
 * @author dawn.constantine
 * @version V1.0
 * @since JDK 1.8
 */
@Service(value = "studentServiceImpl")
public class StudentServiceImpl implements IStudentService {
	@Resource(name = "iStudentDao")
	private IStudentDao iStudentDao;

	public StudentServiceImpl() {

	}

	@Override
	public List<Student> findAllStudentPageable(int page, int size) {
		Page<Student> resultPage = iStudentDao.findAll(PageRequest.of(page, size));
		List<Student> resultList = resultPage.getContent();
		return resultList;
	}

	@Override
	public int deleteStudent(Long stuId) {
		int result = 1;
		try {
			iStudentDao.deleteById(stuId);
		} catch (Exception e) {
			result = 0;
		}
		return result;
	}

	@Override
	public List<Student> findAllStudent() {
		return iStudentDao.findAll();
	}

	@Override
	public int addStudent(Student student) {
		int result = 1;
		try {
			iStudentDao.save(student);
		} catch (Exception e) {
			result = 0;
		}
		return result;
	}

	@Override
	public Student findStudentById(Long stuId) {
		return iStudentDao.findById(stuId).get();
	}

	@Override
	public int updateStudent(Student student) {
		int result = 1;
		try {
			iStudentDao.saveAndFlush(student);
		} catch (Exception e) {
			result = 0;
		}
		return result;
	}

}
