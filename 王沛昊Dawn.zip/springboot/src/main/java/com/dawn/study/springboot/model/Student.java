/**
 * Project Name:springboot
 * File Name:Student.java
 * Package Name:com.dawn.study.springboot.model
 * Date:2018年9月3日下午12:48:03
 * Copyright (c) 2018, 806768654@qq.com All Rights Reserved.
 *
 */
package com.dawn.study.springboot.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * ClassName: Student <br/>
 * Description: 学生实体类 <br/>
 * <br/>
 * date: 2018年9月3日 下午12:48:03 <br/>
 *
 * @author dawn.constantine
 * @version V1.0
 * @since JDK 1.8
 */
@Entity
public class Student implements Serializable {
	private static final long serialVersionUID = 513473680761795500L;

	@Id
	private Long stuId;

	@Column(nullable = false)
	private String stuName;

	@Column(nullable = false)
	private String stuGender;

	@Column(nullable = false)
	private String stuClass;

	@Column(nullable = false)
	private String stuMajor;

	public Student() {

	}

	public Long getStuId() {
		return stuId;
	}

	public void setStuId(Long stuId) {
		this.stuId = stuId;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public String getStuGender() {
		return stuGender;
	}

	public void setStuGender(String stuGender) {
		this.stuGender = stuGender;
	}

	public String getStuClass() {
		return stuClass;
	}

	public void setStuClass(String stuClass) {
		this.stuClass = stuClass;
	}

	public String getStuMajor() {
		return stuMajor;
	}

	public void setStuMajor(String stuMajor) {
		this.stuMajor = stuMajor;
	}
}
