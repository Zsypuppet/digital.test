/**
 * Project Name:springboot
 * File Name:IStudentService.java
 * Package Name:com.dawn.study.springboot.service
 * Date:2018年9月3日下午5:02:31
 * Copyright (c) 2018, 806768654@qq.com All Rights Reserved.
 *
 */
package com.dawn.study.springboot.service;

import java.util.List;

import com.dawn.study.springboot.model.Student;

/**
 * ClassName: IStudentService <br/>
 * Description: 学生service接口 <br/>
 * <br/>
 * date: 2018年9月3日 下午5:02:31 <br/>
 *
 * @author dawn.constantine
 * @version V1.0
 * @since JDK 1.8
 */
public interface IStudentService {
	public List<Student> findAllStudentPageable(int page, int size);

	public List<Student> findAllStudent();

	public int deleteStudent(Long stuId);

	public int addStudent(Student student);

	public Student findStudentById(Long stuId);

	public int updateStudent(Student student);
}
