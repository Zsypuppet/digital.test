/**
 * Project Name:springboot
 * File Name:StudentController.java
 * Package Name:com.dawn.study.springboot.controller
 * Date:2018年9月3日上午11:13:58
 * Copyright (c) 2018, 806768654@qq.com All Rights Reserved.
 *
 */
package com.dawn.study.springboot.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.dawn.study.springboot.model.Student;
import com.dawn.study.springboot.service.IStudentService;

/**
 * ClassName: StudentController <br/>
 * Description: 学生控制层 <br/>
 * <br/>
 * date: 2018年9月3日 上午11:13:58 <br/>
 *
 * @author dawn.constantine
 * @version V1.0
 * @since JDK 1.8
 */
@Controller
public class StudentController {
	@Resource(name = "studentServiceImpl")
	private IStudentService studentSerivce;

	public StudentController() {

	}

	@RequestMapping(value = "/allstudent", method = RequestMethod.GET)
	public String allStudent(Model model) {
		model.addAttribute("studentList", studentSerivce.findAllStudent());
		return "showallstudent";
	}

	@RequestMapping(value = "/deletestudent/{stuId}", method = RequestMethod.DELETE)
	public String deleteStudent(@PathVariable("stuId") String stuId) {
		studentSerivce.deleteStudent(Long.parseLong(stuId));
		return "redirect:/allstudent";
	}

	@RequestMapping(value = "/addstudent", method = RequestMethod.GET)
	public String addStudent() {
		return "addstudent";
	}

	@RequestMapping(value = "/addstudentcontroller", method = RequestMethod.POST)
	public String addStudent(String stuId, String stuName, String stuGender, String stuClass, String stuMajor) {
		Student student = new Student();
		student.setStuId(Long.parseLong(stuId));
		student.setStuName(stuName);
		student.setStuGender(stuGender);
		student.setStuClass(stuClass);
		student.setStuMajor(stuMajor);
		studentSerivce.addStudent(student);
		return "redirect:/allstudent";
	}

	@RequestMapping(value = "/updatestudent/{stuId}", method = RequestMethod.GET)
	public String updateStudent(@PathVariable("stuId") String stuId, Model model) {
		Student student = studentSerivce.findStudentById(Long.parseLong(stuId));
		model.addAttribute("student", student);
		return "updatestudent";
	}

	@RequestMapping(value = "/updatestudentcontroller", method = RequestMethod.PUT)
	public String updateStudent(String stuId, String stuName, String stuGender, String stuClass, String stuMajor) {
		Student student = new Student();
		student.setStuId(Long.parseLong(stuId));
		student.setStuName(stuName);
		student.setStuGender(stuGender);
		student.setStuClass(stuClass);
		student.setStuMajor(stuMajor);
		studentSerivce.updateStudent(student);
		return "redirect:/allstudent";
	}
}
