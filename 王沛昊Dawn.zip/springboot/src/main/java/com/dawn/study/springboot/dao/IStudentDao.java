/**
 * Project Name:springboot
 * File Name:IStudentDao.java
 * Package Name:com.dawn.study.springboot.dao
 * Date:2018年9月3日下午1:03:03
 * Copyright (c) 2018, 806768654@qq.com All Rights Reserved.
 *
 */
package com.dawn.study.springboot.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dawn.study.springboot.model.Student;

/**
 * ClassName: IStudentDao <br/>
 * Description: 学生dao接口 <br/>
 * <br/>
 * date: 2018年9月3日 下午1:03:03 <br/>
 *
 * @author dawn.constantine
 * @version V1.0
 * @since JDK 1.8
 */
@Repository(value = "iStudentDao")
public interface IStudentDao extends JpaRepository<Student, Long> {

}
