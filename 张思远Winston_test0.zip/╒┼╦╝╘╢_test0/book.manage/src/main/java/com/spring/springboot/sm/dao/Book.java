/**
 * Project Name:book.manage
 * File Name:book.java
 * Package Name:com.spring.springboot.sm.dao
 * Date:2018年9月3日下午2:20:54
 * Copyright (c) 2018, 1021880615@qq.com All Rights Reserved.
 *
 */
package com.spring.springboot.sm.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ClassName: book <br/>
 * Description: 书籍实体类. <br/><br/>
 * date: 2018年9月3日 下午2:20:54 <br/>
 *
 * @author winston.zhang
 * @version V1.0
 * @since JDK 1.8
 */


@Table(name="BOOK")
@Entity
public class Book {
	@Id
    @GeneratedValue
    @Column(name = "BID")
    private int bid;               //书籍编号
	
    @Column(name = "BNAME",length = 20,nullable = false)
    private String bname;           //书名
    
    @Column(name = "BAUTHOR",length = 10,nullable = false)
    private String bauthor;         //书籍作者
    
    @Column(name = "BPRICE",nullable = false)
    private int bprice;             //书籍价格

	/**
	 * Creates a new instance of book.
	 *
	 */
	
	public Book() {
		super();
	}

	/**
	 * bid.
	 *
	 * @return  the bid
	 * @since   JDK 1.8
	 */

	public final long getBid() {
		return bid;
	}

	/**
	 * bid.
	 *
	 * @param   bid    the bid to set
	 * @since   JDK 1.8
	 */
	public final void setBid(int bid) {
		this.bid = bid;
	}

	/**
	 * bname.
	 *
	 * @return  the bname
	 * @since   JDK 1.8
	 */
	public final String getBname() {
		return bname;
	}

	/**
	 * bname.
	 *
	 * @param   bname    the bname to set
	 * @since   JDK 1.8
	 */
	public final void setBname(String bname) {
		this.bname = bname;
	}

	/**
	 * bauthor.
	 *
	 * @return  the bauthor
	 * @since   JDK 1.8
	 */
	public final String getBauthor() {
		return bauthor;
	}

	/**
	 * bauthor.
	 *
	 * @param   bauthor    the bauthor to set
	 * @since   JDK 1.8
	 */
	public final void setBauthor(String bauthor) {
		this.bauthor = bauthor;
	}

	/**
	 * bprice.
	 *
	 * @return  the bprice
	 * @since   JDK 1.8
	 */
	public final int getBprice() {
		return bprice;
	}

	/**
	 * bprice.
	 *
	 * @param   bprice    the bprice to set
	 * @since   JDK 1.8
	 */
	public final void setBprice(int bprice) {
		this.bprice = bprice;
	}
    
    
}
