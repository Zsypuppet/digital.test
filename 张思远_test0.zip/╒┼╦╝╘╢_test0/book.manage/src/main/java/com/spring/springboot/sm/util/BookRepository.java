/**
 * Project Name:book.manage
 * File Name:BookRepoisity.java
 * Package Name:com.spring.springboot.sm.util
 * Date:2018年9月3日下午3:03:20
 * Copyright (c) 2018, 1021880615@qq.com All Rights Reserved.
 *
 */
package com.spring.springboot.sm.util;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.springboot.sm.dao.Book;

/**
 * ClassName: BookRepoisity <br/>
 * Description: TODO ADD REASON(可选). <br/><br/>
 * date: 2018年9月3日 下午3:03:20 <br/>
 *
 * @author winston.zhang
 * @version V1.0
 * @since JDK 1.8
 */
public interface BookRepository extends JpaRepository<Book,Integer>{
	 Book findByBid(int bid);
	 void deleteByBid(int bid);
}
