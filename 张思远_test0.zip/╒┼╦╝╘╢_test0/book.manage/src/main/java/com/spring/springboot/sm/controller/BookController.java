/**
 * Project Name:book.manage
 * File Name:BookController.java
 * Package Name:com.spring.springboot.sm.controller
 * Date:2018年9月3日下午3:28:14
 * Copyright (c) 2018, 1021880615@qq.com All Rights Reserved.
 *
 */
package com.spring.springboot.sm.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.springboot.sm.dao.Book;
import com.spring.springboot.sm.service.BookService;

/**
 * ClassName: BookController <br/>
 * Description: TODO ADD REASON(可选). <br/><br/>
 * date: 2018年9月3日 下午3:28:14 <br/>
 *
 * @author winston.zhang
 * @version V1.0
 * @since JDK 1.8
 */

@Controller
public class BookController {
	@Resource
    BookService bookService;
 
 
    @RequestMapping("/")
    public String index() {
        return "redirect:/mainFrm";
    }
 
    @RequestMapping("/mainFrm")
    public String mainFrm(Model model) {
        List<Book> books=bookService.getBookList();
        model.addAttribute("books", books);
        return "book/mainFrm";
    }
 
    @RequestMapping("/toAdd")
    public String toAdd() {
        return "book/bookAdd";
    }
 
    @RequestMapping("/add")
    public String add(Book book) {
        bookService.saveBook(book);
        return "redirect:/mainFrm";
    }
 
    @RequestMapping("/toEdit")
    public String toEdit(Model model,int bid) {
    	System.out.println(bid);
        Book book=bookService.findBookByBid(bid);
        System.out.println(book);
        model.addAttribute("book", book);
        return "book/bookEdit";
    }
 
    @RequestMapping("/edit")
    public String edit(Book book) {
        bookService.editBook(book);
        return "redirect:/mainFrm";
    }
 
 
    @RequestMapping("/delete")
    public String delete(int bid) {
        bookService.deleteBook(bid);
        return "redirect:/mainFrm";
    }

}
