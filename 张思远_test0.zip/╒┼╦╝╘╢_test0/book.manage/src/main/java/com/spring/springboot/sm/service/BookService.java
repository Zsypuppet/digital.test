/**
 * Project Name:book.manage
 * File Name:bookservice.java
 * Package Name:com.spring.springboot.sm.service
 * Date:2018年9月3日下午2:39:31
 * Copyright (c) 2018, 1021880615@qq.com All Rights Reserved.
 *
 */
package com.spring.springboot.sm.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.spring.springboot.sm.dao.Book;

/**
 * ClassName: bookservice <br/>
 * Description: TODO ADD REASON(可选). <br/><br/>
 * date: 2018年9月3日 下午2:39:31 <br/>
 *
 * @author winston.zhang
 * @version V1.0
 * @since JDK 1.8
 */


public interface BookService {
	/**
	 * 
	 * saveBook:添加书籍. <br/>
	 *
	 * @author winston.zhang
	 * @param book
	 * @since JDK 1.8
	 */
	public void saveBook(Book book);
	/**
	 * 
	 * deleteBook:删除书籍. <br/>
	 *
	 * @author winston.zhang
	 * @param bid
	 * @since JDK 1.8
	 */
	public void deleteBook(int bid);
	/**
	 * 
	 * editBook:编辑书籍. <br/>
	 *
	 * @author winston.zhang
	 * @param book
	 * @since JDK 1.8
	 */
	public void editBook(Book book);
	/**
	 * 
	 * getBookList:获取全部书籍. <br/>
	 *
	 * @author winston.zhang
	 * @return
	 * @since JDK 1.8
	 */
	public List<Book> getBookList();
	/**
	 * 
	 * findBookByBid:根据编号查询书籍. <br/>
	 *
	 * @author winston.zhang
	 * @param bid
	 * @return
	 * @since JDK 1.8
	 */
	public Book findBookByBid(int bid);
}
