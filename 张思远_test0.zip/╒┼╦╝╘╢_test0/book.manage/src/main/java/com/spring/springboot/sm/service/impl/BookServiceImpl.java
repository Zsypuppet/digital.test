/**
 * Project Name:book.manage
 * File Name:BookServiceImpl.java
 * Package Name:com.spring.springboot.sm.service.impl
 * Date:2018年9月3日下午2:59:35
 * Copyright (c) 2018, 1021880615@qq.com All Rights Reserved.
 *
 */
package com.spring.springboot.sm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.springboot.sm.dao.Book;
import com.spring.springboot.sm.service.BookService;
import com.spring.springboot.sm.util.BookRepository;

/**
 * ClassName: BookServiceImpl <br/>
 * Description: TODO ADD REASON(可选). <br/><br/>
 * date: 2018年9月3日 下午2:59:35 <br/>
 *
 * @author winston.zhang
 * @version V1.0
 * @since JDK 1.8
 */

@Service
public class BookServiceImpl implements BookService {
	@Autowired
    private BookRepository bookRepository;
	/**
	 * @see com.spring.springboot.sm.service.BookService#saveBook(com.spring.springboot.sm.dao.Book)
	 */
	@Override
	public void saveBook(Book book) {
		bookRepository.save(book);
		
	}

	/**
	 * @see com.spring.springboot.sm.service.BookService#deleteBook(java.lang.Integer)
	 */
	@Override
	public void deleteBook(int bid) {
		bookRepository.deleteById(bid);
		
	}

	/**
	 * @see com.spring.springboot.sm.service.BookService#editBook(com.spring.springboot.sm.dao.Book)
	 */
	@Override
	public void editBook(Book book) {
		bookRepository.save(book);
		
	}

	/**
	 * @see com.spring.springboot.sm.service.BookService#getBookList()
	 */
	@Override
	public List<Book> getBookList() {
		return bookRepository.findAll();
	}

	/**
	 * @see com.spring.springboot.sm.service.BookService#findBookByBid(java.lang.Integer)
	 */
	@Override
	public Book findBookByBid(int bid) {
		return bookRepository.findByBid(bid);
	}
	
}
