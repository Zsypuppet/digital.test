/**
 * Project Name:book.manage
 * File Name:TestDemo.java
 * Package Name:com.spring.springboot.sm.controller
 * Date:2018年9月3日上午9:43:06
 * Copyright (c) 2018, 1021880615@qq.com All Rights Reserved.
 *
 */
package com.spring.springboot.sm.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * ClassName: TestDemo <br/>
 * Description: TODO ADD REASON(可选). <br/><br/>
 * date: 2018年9月3日 上午9:43:06 <br/>
 *
 * @author winston.zhang
 * @version V1.0
 * @since JDK 1.8
 */

@RestController
public class TestDemo {
	
	@RequestMapping("/hello")
	public String hello() {
		return "hello returned by server";
	}

}
