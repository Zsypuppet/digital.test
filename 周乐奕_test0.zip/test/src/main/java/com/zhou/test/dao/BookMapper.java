/**
 * Project Name:test
 * File Name:BookMapper.java
 * Package Name:com.zhou.test.dao
 * Date:2018年9月2日下午1:47:17
 * Copyright (c) 2018, Rochester.zhou@clpsglobal.com All Rights Reserved.
 *
 */
package com.zhou.test.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.zhou.test.bean.Book;

/**
 * ClassName: BookMapper
 * Description: 数据持久层相关.
 * date: 2018年9月2日 下午1:47:17
 *
 * @author Rochester.Zhou
 * @version V1.0
 */
public interface BookMapper {
	
	/**
	 * 
	 * findAllBook:查找所有的书籍.
	 *
	 * @author Rochester.Zhou
	 * @return
	 */
	@Select("select * from book order by book_id desc")
	List<Book> findAllBook();
	
	/**
	 * 
	 * findBookById:通过id查找书籍.
	 *
	 * @author Rochester.Zhou
	 * @param book_id
	 * @return
	 */
	@Select("select * from book where book_id = #{book_id}")
	Book findBookById(Integer book_id);
	
	/**
	 * 
	 * saveBook:新增一本书籍.
	 *
	 * @author Rochester.Zhou
	 * @param book
	 */
	@Insert("insert into book values(null,#{book_name},#{book_desc},#{book_author},#{book_price})")
	void saveBook(Book book);
	
	/**
	 * 
	 * deleteBookById:根据id删除书籍.
	 *
	 * @author Rochester.Zhou
	 * @param bookId
	 */
	@Delete("delete from book where book_id = #{book_id}")
	void deleteBookById(Integer book_id);
	
	/**
	 * 
	 * updateBook:更新书籍.
	 *
	 * @author Rochester.Zhou
	 * @param book
	 */
	@Update("update book set book_name=#{book_name},book_desc=#{book_desc},book_author=#{book_author},book_price=#{book_price} where book_id=#{book_id}")
	void updateBook(Book book);
}
