/**
 * Project Name:test
 * File Name:BookController.java
 * Package Name:com.zhou.test.controller
 * Date:2018年9月3日上午9:01:38
 * Copyright (c) 2018, Rochester.zhou@clpsglobal.com All Rights Reserved.
 *
 */
package com.zhou.test.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zhou.test.bean.Book;
import com.zhou.test.service.IBookService;


/**
 * ClassName: BookController
 * date: 2018年9月3日 上午9:01:38
 *
 * @author Rochester.Zhou
 * @version V1.0
 */
@Controller
@RequestMapping("/books")
public class BookController {

	@Autowired
	IBookService bookService;
	
	/**
	 * 
	 * showAllBook:显示所有的书籍.
	 *
	 * @author Rochester.Zhou
	 * @param session
	 * @return
	 */
	@RequestMapping(value="/index",method=RequestMethod.GET)
	public String showAllBook(HttpSession session){
		List<Book> books = bookService.showAllBook();
		session.setAttribute("books", books);
		return "index";
	}
	
	/**
	 * 
	 * toSavePage:跳转到新增书籍的页面.
	 *
	 * @author Rochester.Zhou
	 * @return
	 */
	@RequestMapping(value="/toSavePage",method=RequestMethod.GET)
	public String toSavePage() {
		return "addPage";
	}
	
	/**
	 * 
	 * saveBook:新增书籍.
	 *
	 * @author Rochester.Zhou
	 * @param book
	 * @param session
	 * @return
	 */
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String saveBook(Book book,HttpSession session) {
		bookService.saveBook(book);
		session.setAttribute("msg", "添加成功");
		return "redirect:index";
	}
	
	/**
	 * 
	 * deleteBook:根据book_id删除书籍.
	 *
	 * @author Rochester.Zhou
	 * @param book_id
	 * @return
	 */
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public String deleteBook(Integer book_id) {
		bookService.deleteBook(book_id);
		return "redirect:index";
	}
	
	/**
	 * 
	 * toUpdatePage:根据book_id,查找出对应的书籍，放进session,跳转到更新页面.
	 *
	 * @author Rochester.Zhou
	 * @param book_id
	 * @param session
	 * @return
	 */
	@RequestMapping(value="/toUpdatePage",method=RequestMethod.GET)
	public String toUpdatePage(Integer book_id,HttpSession session) {
		Book book = bookService.findOneBook(book_id);
		session.setAttribute("book", book);
		return "editPage";
	}
	
	/**
	 * 
	 * updateBook:执行更新操作.
	 *
	 * @author Rochester.Zhou
	 * @param book
	 * @param session
	 * @return
	 */
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public String updateBook(Book book,HttpSession session) {
		bookService.updateBook(book);
		session.setAttribute("msg", "更新成功");
		return "redirect:index";
	}
}
