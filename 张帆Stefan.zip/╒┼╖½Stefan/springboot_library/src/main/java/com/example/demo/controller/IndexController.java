package com.example.demo.controller;

import com.example.demo.entity.Book;
import com.example.demo.service.IBookService;
import org.apache.commons.lang.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 图书馆首页控制层
 * Created by msi on 2018/9/1.
 */
@Controller
public class IndexController {
    @Autowired
    private IBookService bookService;

    /**
     *
     * @param request
     * @return 到主界面
     */
    @RequestMapping(value = "", method = RequestMethod.GET)
    public String index(HttpServletRequest request) {
        List<Book> books = bookService.queryBookAll();
        request.setAttribute("books", books);
        return "index";
    }

    /**
     *
     * @param id
     * @param request
     * @return 到添加书籍界面
     */
    @RequestMapping(value = "/add/{id}", method = RequestMethod.GET)
    public String add(@PathVariable int id, HttpServletRequest request) {
        Book book = bookService.queryById(id);
        if (book != null) {
            request.setAttribute("book", book);
        }
        return "add";
    }

    /**
     * 添加书籍操作
     * @param request
     * @return 成功 1
     *          失败 0
     */
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    @ResponseBody
    public Integer save(HttpServletRequest request) {
        int i=0;
        int id = NumberUtils.toInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String author = request.getParameter("author");
        Book book = bookService.queryById(id);
        if (book == null) {
            book = new Book();
        }
        book.setBookName(name);
        book.setBookAuthor(author);
        List<Book> list= bookService.queryBookAll();
        for (Book book1: list) {
            if (book.getBookName().equals(book1.getBookName())&&book.getBookAuthor().equals(book1.getBookAuthor())){
                return i;
            }
        }
        i = bookService.saveBook(book);
        return i;
    }

    /**
     *
     * @param id
     * @param request
     * @return 到更新书籍界面
     */
    @RequestMapping(value = "/update/{id}", method = RequestMethod.GET)
    public String updateView(@PathVariable int id, HttpServletRequest request) {
        Book book = bookService.queryById(id);
        if (book != null) {
            request.setAttribute("book", book);
        }
        return "update";
    }

    /**
     *
     * @param request
     * @return 成功 1
     *          失败 0
     */
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    @ResponseBody
    public Integer update(HttpServletRequest request){
        int i=0;
        int id = NumberUtils.toInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String author = request.getParameter("author");
        Book book = bookService.queryById(id);
        book.setBookName(name);
        book.setBookAuthor(author);
        List<Book> list= bookService.queryBookAll();
        for (Book book1: list) {
            if (book.getBookName().equals(book1.getBookName())&&book.getBookAuthor().equals(book1.getBookAuthor())){
                return i;
            }
        }
        i = bookService.updateBook(book);
        return i;
        }
    /**
     * 删除操作
     * @param id
     * @param request
     * @return 成功 1
     *          失败 0
     */
    @RequestMapping(value = "/del/{id}", method = RequestMethod.GET)
    @ResponseBody
    public Integer del(@PathVariable int id, HttpServletRequest request) {
        int i =0;
        Book book = bookService.queryById(id);
        if (book != null) {
            i = bookService.deleteBookById(id);
            return i;
        }
        return i;
    }

}
