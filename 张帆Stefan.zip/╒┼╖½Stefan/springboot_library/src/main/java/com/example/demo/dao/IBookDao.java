package com.example.demo.dao;

import com.example.demo.entity.Book;

import java.util.List;

/**
 * Book数据实现层接口
 * Created by msi on 2018/9/1.
 */
public interface IBookDao {
    /**
     * 添加书籍
     * @param book  Book实体
     * @return 成功 1
     *          失败 0
     */
    public int saveBook(Book book);

    /**
     * 删除书籍
     * @param id  书的id
     * @return 成功 1
     *          失败 0
     */
    public int deleteBookById(int id);

    /**
     * 更新书籍
     * @param book  book
     * @return 成功 1
     *          失败 0
     */
    public int uodateBook(Book book);
    /**
     * 查询所有图书信息
     * @return Book的集合
     */
    public List<Book> queryBookAll();

    /**
     * 通过id查找图书信息
     * @return 单本图书信息
     */
    public Book queryById(int id);


}
