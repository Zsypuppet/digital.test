package com.example.demo.dao.impl;

import com.example.demo.dao.IBookDao;
import com.example.demo.entity.Book;
import com.example.demo.entity.BookRowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by msi on 2018/9/1.
 */
@Repository
public class BookDaoImpl implements IBookDao {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    private static int n = 0;

    private static final String SQL_SAVE="INSERT INTO BOOK (BOOKNAME,BOOKAUTHOR) VALUES (?,?)";
    private static final String SQL_DELETEBYID="DELETE FROM BOOK WHERE BOOKID=?";
    private static final String SQL_QUERYALL="SELECT * FROM BOOK";
    private static final String SQL_QUERYBYID="SELECT * FROM BOOK WHERE BOOKID=?";
    private static final String SQL_UPDATE="UPDATE BOOK SET BOOKNAME=?,BOOKAUTHOR=? WHERE BOOKID=?";
    @Override
    public int saveBook(Book book) {
        try {
            n = jdbcTemplate.update(SQL_SAVE, new Object[]{book.getBookName(), book.getBookAuthor()});
            return n;
        } catch (DataAccessException e) {
            e.printStackTrace();
        }
        return n;
    }

    @Override
    public int deleteBookById(int id) {
        try {
            n = jdbcTemplate.update(SQL_DELETEBYID, id);
        } catch (DataAccessException e) {
            e.printStackTrace();
        }
        return n;
    }

    @Override
    public int uodateBook(Book book) {
        try {
            n=jdbcTemplate.update(SQL_UPDATE,new Object[]{book.getBookName(),book.getBookAuthor(),book.getBookId()});
            return n;
        } catch (DataAccessException e) {
            e.printStackTrace();
        }
        return n;
    }

    @Override
    public List<Book> queryBookAll() {
        try {
            List<Book> list = jdbcTemplate.query(SQL_QUERYALL, new BookRowMapper());
            return list;
        } catch (DataAccessException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public Book queryById(int id) {
        Book book = new Book();
        try {
            book = jdbcTemplate.queryForObject(SQL_QUERYBYID, new BookRowMapper(), id);
            return book;
        } catch (DataAccessException e) {
            e.printStackTrace();
        }
        return null;
    }


}
