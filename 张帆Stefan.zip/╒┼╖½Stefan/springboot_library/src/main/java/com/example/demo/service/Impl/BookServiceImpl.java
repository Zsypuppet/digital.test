package com.example.demo.service.Impl;

import com.example.demo.dao.IBookDao;
import com.example.demo.entity.Book;
import com.example.demo.service.IBookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by msi on 2018/9/1.
 */
@Service
public class BookServiceImpl implements IBookService {
    @Autowired
    private IBookDao bookDao;
    @Override
    public int saveBook(Book book) {
        return bookDao.saveBook(book);
    }

    @Override
    public int deleteBookById(int id) {
        return bookDao.deleteBookById(id);
    }

    @Override
    public List<Book> queryBookAll() {
        return bookDao.queryBookAll();
    }

    @Override
    public Book queryById(int id) {
        return bookDao.queryById(id);
    }

    @Override
    public int updateBook(Book book) {
        return bookDao.uodateBook(book);
    }


}
