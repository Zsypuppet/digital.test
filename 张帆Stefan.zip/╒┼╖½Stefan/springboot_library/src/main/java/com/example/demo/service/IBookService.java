package com.example.demo.service;

import com.example.demo.entity.Book;

import java.util.List;

/**
 * book服务层接口
 * Created by msi on 2018/9/1.
 */
public interface IBookService {
    /**
     * 保存书籍（添加和更新写在一起）
     * @param book  Book实体
     * @return 成功 1
     *          失败 0
     */
    public int saveBook(Book book);

    /**
     * 删除书籍
     * @param id  书的id
     * @return 成功 1
     *          失败 0
     */
    public int deleteBookById(int id);
    /**
     * 查询所有图书信息
     * @return Book的集合
     */
    public List<Book> queryBookAll();

    /**
     * 通过id查找图书信息
     * @param id
     * @return 单本图书信息
     */
    public Book queryById(int id);

    /**
     * 更新书籍
     * @param book
     * @return 成功 1
     *          失败 0
     */
    public int updateBook(Book book);


}
